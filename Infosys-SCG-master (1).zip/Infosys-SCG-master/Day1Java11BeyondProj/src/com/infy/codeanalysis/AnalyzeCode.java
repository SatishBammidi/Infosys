package com.infy.codeanalysis;

public class AnalyzeCode {

}
//Pascal-Casing of Class Names
class Finance{
	//Camel-Casing of Variables
	double radius;
	double areaCircle;
	double volumeSphere;

}
class VehicleFinance extends Finance{
	//Camel-Casing of Methods
	public int calculateInterest(double rate, int timePeriod){
	   return 0;
	}

}

abstract class MyAbstraction
{
	abstract void print();
}
