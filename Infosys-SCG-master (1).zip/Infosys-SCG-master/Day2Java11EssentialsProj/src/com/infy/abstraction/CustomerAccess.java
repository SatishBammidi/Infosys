package com.infy.abstraction;

public interface CustomerAccess {
	
	void setMobileNo(String mobileNo);
	String getMobileNo();
}
