package com.infy.functionalInterface;

@FunctionalInterface
public interface CurrencyConverterInterface {
	
	double dollarToRupee(double dollar);

}
