package com.infy.abstractdemos;

public class HDFCBankApp  extends BankingApp{

	@Override
	public void withdraw(double amount) {
		System.out.println(amount+" has been withdraw from HDFC Bank");
		
	}
	

}
