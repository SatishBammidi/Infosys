package com.infy.abstractdemos;

public class SavingAccount extends Account {
	public SavingAccount() {
		System.out.println("Saving Account Constructor");
	}

}
