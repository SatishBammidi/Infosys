package com.infy.abstractdemos;

// ARE CALLED AS CONCRETE CLASS
public class HelloWorld {
	public void show()
	{
		System.out.println("Hey !.. I am from HelloWorld Family..");
	}
}
