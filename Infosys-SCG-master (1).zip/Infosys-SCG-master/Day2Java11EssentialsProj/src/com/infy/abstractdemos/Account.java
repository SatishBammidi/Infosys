package com.infy.abstractdemos;

public class Account {
	public Account() {
		System.out.println("Account Constructor..");
	}

}
