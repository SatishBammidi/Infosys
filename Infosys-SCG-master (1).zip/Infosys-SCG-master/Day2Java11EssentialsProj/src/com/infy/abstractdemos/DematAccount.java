package com.infy.abstractdemos;

public class DematAccount extends Account{
	public DematAccount() {
		System.out.println("Demat Account Constructor..");
	}

}
