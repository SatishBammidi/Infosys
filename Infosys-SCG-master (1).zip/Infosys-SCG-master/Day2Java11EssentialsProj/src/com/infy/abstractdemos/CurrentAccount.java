package com.infy.abstractdemos;

public class CurrentAccount extends Account{
	public CurrentAccount() {
		System.out.println("Saving Account Constructor");
	}

}
