package com.infy.finaldemo;

public class FinalClass {
	
	private int x;

	public int getX() {
		return x;
	}

	public final void setX(int x) {
		this.x = x;
	}
}
