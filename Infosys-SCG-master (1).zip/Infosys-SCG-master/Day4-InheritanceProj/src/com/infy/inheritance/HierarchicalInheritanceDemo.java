package com.infy.inheritance;

public class HierarchicalInheritanceDemo {
	public static void main(String args[])
	{
		System.out.println("From HierarchicalInheritanceDemo ...");
	}
}
class Class1
{
	public static void main(String args[])
	{
		System.out.println("From Class1 ...");
	}
}
class Class2
{
	
}
class Tester
{
	public static void main(String args[])
	{
		System.out.println("From Tester Class");
	}
}